let you = document.querySelector('.me');
let container = document.querySelector('.container')


function phones(amori){
    you.src = amori;
}
function colors(color){
    container.style.background = color;
}